class BaseApi {
  static const quoteUrl = 'https://zenquotes.io/api/quotes';
  static const dictionaryUrl = 'https://api.dictionaryapi.dev/api/v2/entries/en/';
}
